package dev.autoforge.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job as CoJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class Vm(app: Application) : AndroidViewModel(app) {
    private val api = Api(app)
    var prompt by mutableStateOf("")
    var compose by mutableStateOf(true)
    var java by mutableStateOf(false)
    var current by mutableStateOf<Job?>(null)
    var history by mutableStateOf<List<Job>>(emptyList())
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var serverUrl by mutableStateOf(api.serverUrl())
    private var poller: CoJob? = null

    fun saveServer(url: String) {
        api.setServerUrl(url); serverUrl = api.serverUrl()
        message = "Server set to $serverUrl"; loadHistory()
    }

    fun chooseCompose(v: Boolean) { compose = v; if (v) java = false }
    fun chooseJava(v: Boolean) { java = v; if (v) compose = false }

    fun submit(onStarted: () -> Unit) {
        if (prompt.isBlank() || busy) return
        busy = true
        viewModelScope.launch {
            runCatching { api.createJob(prompt.trim(), if (compose) "compose" else "xml", if (java) "java" else "kotlin") }
                .onSuccess { current = it; prompt = ""; track(it.id); onStarted() }
                .onFailure { message = it.message }
            busy = false
        }
    }

    fun open(id: String) { viewModelScope.launch { runCatching { api.getJob(id) }.onSuccess { current = it; if (it.running) track(id) }.onFailure { message = it.message } } }

    private fun track(id: String) {
        poller?.cancel()
        poller = viewModelScope.launch {
            while (true) {
                runCatching { api.getJob(id) }.onSuccess { current = it; if (!it.running) { loadHistory(); return@launch } }
                delay(2000)
            }
        }
    }

    fun loadHistory() { viewModelScope.launch { runCatching { api.listJobs() }.onSuccess { history = it }.onFailure { message = it.message } } }
    fun delete(id: String) { viewModelScope.launch { runCatching { api.deleteJob(id) }.onFailure { message = it.message }; loadHistory() } }

    fun fetch(job: Job, kind: String, onFile: (File) -> Unit) {
        viewModelScope.launch {
            message = "Downloading…"
            runCatching {
                val dir = File(getApplication<Application>().cacheDir, "dl")
                api.download("/v1/jobs/${job.id}/$kind", File(dir, if (kind == "apk") "${job.id}.apk" else "${job.id}-source.zip"))
            }.onSuccess { message = null; onFile(it) }.onFailure { message = it.message }
        }
    }
}

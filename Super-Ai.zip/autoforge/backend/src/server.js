import express from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { createJob, loadJob, listJobs, deleteJob, saveJob, view, jobDir, ID_RE, DATA } from './store.js';
import { runJob } from './pipeline.js';

const SECRET = process.env.SERVER_SECRET;
if (!SECRET || SECRET.length < 16) { console.error('Set SERVER_SECRET (16+ chars)'); process.exit(1); }
const sign = id => crypto.createHmac('sha256', SECRET).update(id).digest('hex').slice(0, 32);
const MAX_PER_DAY = +(process.env.MAX_JOBS_PER_DAY || 10);
const CONCURRENCY = +(process.env.BUILD_CONCURRENCY || 1);

const app = express();
app.use(express.json({ limit: '32kb' }));

app.post('/v1/register', (req, res) => {
  const id = crypto.randomUUID();
  res.json({ token: `${id}.${sign(id)}` });
});

function auth(req, res, next) {
  const [id, sig] = (req.headers.authorization || '').replace('Bearer ', '').split('.');
  if (!id || !sig || sig.length !== 32 || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(sign(id)))) return res.status(401).json({ error: 'unauthorized' });
  req.deviceId = id; next();
}
const own = (req, res) => { const j = loadJob(req.params.id); if (!j || j.deviceId !== req.deviceId) { res.status(404).json({ error: 'not found' }); return null; } return j; };

// simple job queue
const queue = []; let active = 0;
function pump() {
  while (active < CONCURRENCY && queue.length) {
    const job = queue.shift(); active++;
    runJob(job).finally(() => { active--; pump(); });
  }
}

app.post('/v1/jobs', auth, (req, res) => {
  const prompt = String(req.body.prompt || '').trim();
  if (prompt.length < 5 || prompt.length > 4000) return res.status(400).json({ error: 'Describe your app in 5-4000 characters' });
  const recent = listJobs(req.deviceId).filter(j => Date.now() - j.createdAt < 864e5).length;
  if (recent >= MAX_PER_DAY) return res.status(429).json({ error: `Daily limit of ${MAX_PER_DAY} builds reached` });
  const ui = req.body.ui === 'xml' ? 'xml' : 'compose';
  const language = ui === 'compose' ? 'kotlin' : (req.body.language === 'java' ? 'java' : 'kotlin');
  const job = createJob(req.deviceId, prompt, { mode: ui, language });
  queue.push(job); pump();
  res.status(201).json(view(job));
});
app.get('/v1/jobs', auth, (req, res) => res.json(listJobs(req.deviceId).map(view)));
app.get('/v1/jobs/:id', auth, (req, res) => { const j = own(req, res); if (j) res.json(view(j)); });
app.get('/v1/jobs/:id/apk', auth, (req, res) => {
  const j = own(req, res); if (!j) return;
  const f = path.join(jobDir(j.id), 'app.apk'); if (!fs.existsSync(f)) return res.status(409).json({ error: 'APK not ready' });
  res.download(f, `${(j.plan?.appName || 'app').replace(/[^\w-]+/g, '_')}.apk`);
});
app.get('/v1/jobs/:id/source', auth, (req, res) => {
  const j = own(req, res); if (!j) return;
  const f = path.join(jobDir(j.id), 'source.zip'); if (!fs.existsSync(f)) return res.status(409).json({ error: 'Source not ready' });
  res.download(f, `${(j.plan?.appName || 'app').replace(/[^\w-]+/g, '_')}-source.zip`);
});
app.delete('/v1/jobs/:id', auth, (req, res) => { const j = own(req, res); if (j) { deleteJob(j.id); res.json({ ok: true }); } });

// crash recovery: jobs interrupted by a restart are marked failed, not left hanging
for (const j of fs.readdirSync(path.join(DATA, 'jobs')).map(loadJob).filter(Boolean)) {
  if (j.status === 'queued' || j.status === 'running') { j.status = 'failed'; j.error = 'Server restarted during build'; saveJob(j); }
}
app.listen(process.env.PORT || 8080, () => console.log('AutoForge backend up'));

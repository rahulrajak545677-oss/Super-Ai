// Fills the shared Gradle cache volume (needs internet ONCE). Real builds then run with --network none.
import fs from 'fs'; import os from 'os'; import path from 'path';
import { writeScaffold, writeDefaults, writeFile } from '../src/template.js';
import { build } from '../src/builder.js';

for (const mode of ['compose', 'xml']) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'af-warm-'));
  const pkg = 'com.autoforge.warm';
  writeScaffold(dir, { pkg, mode });
  writeFile(dir, 'app/src/main/res/values/strings.xml', '<resources><string name="app_name">Warm</string></resources>');
  writeFile(dir, 'app/src/main/java/com/autoforge/warm/MainActivity.kt', mode === 'compose'
    ? 'package com.autoforge.warm\nimport android.os.Bundle\nimport androidx.activity.ComponentActivity\nimport androidx.activity.compose.setContent\nimport androidx.compose.material3.Text\nclass MainActivity : ComponentActivity() { override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { Text("warm") } } }\n'
    : 'package com.autoforge.warm\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity() { override fun onCreate(b: Bundle?) { super.onCreate(b) } }\n');
  writeDefaults(dir, pkg);
  console.log('Warming', mode, '...');
  const r = await build(dir, { online: true });
  console.log(mode, r.ok ? 'OK' : 'FAILED\n' + r.log.slice(-2000));
  if (!r.ok) process.exit(1);
}

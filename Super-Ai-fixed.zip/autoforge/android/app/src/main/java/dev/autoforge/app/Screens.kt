package dev.autoforge.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: Vm, onVoice: () -> Unit, onInstall: (java.io.File) -> Unit, onShare: (java.io.File) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it) } }
    LaunchedEffect(Unit) { vm.loadHistory() }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("AutoForge") }) },
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.AutoAwesome, null) }, label = { Text("Create") })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Build, null) }, label = { Text("Build") })
                    NavigationBarItem(tab == 2, { tab = 2; vm.loadHistory() }, { Icon(Icons.Default.History, null) }, label = { Text("History") })
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).padding(16.dp)) {
                when (tab) {
                    0 -> Home(vm, onVoice) { tab = 1 }
                    1 -> JobScreen(vm, onInstall, onShare)
                    else -> HistoryScreen(vm) { vm.open(it); tab = 1 }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Home(vm: Vm, onVoice: () -> Unit, started: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Describe your app. AutoForge assumes sensible defaults and builds it.", style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(vm.prompt, { vm.prompt = it }, Modifier.fillMaxWidth().heightIn(min = 160.dp),
            label = { Text("e.g. A habit tracker with streaks and daily reminders") },
            trailingIcon = { IconButton(onVoice) { Icon(Icons.Default.Mic, "Speak your idea") } })
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(vm.compose, { vm.chooseCompose(true) }, { Text("Kotlin + Compose") })
            FilterChip(!vm.compose && !vm.java, { vm.compose = false; vm.java = false }, { Text("Kotlin + XML") })
            FilterChip(vm.java, { vm.chooseJava(true) }, { Text("Java + XML") })
        }
        Button({ vm.submit(started) }, Modifier.fillMaxWidth(), enabled = vm.prompt.isNotBlank() && !vm.busy) {
            Text(if (vm.busy) "Submitting…" else "Build my app")
        }
        Text("Builds take several minutes. APKs are debug-signed for sideloading, not Play Store upload.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun JobScreen(vm: Vm, onInstall: (java.io.File) -> Unit, onShare: (java.io.File) -> Unit) {
    val j = vm.current
    if (j == null) { Text("No build selected. Create one first."); return }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(j.appName ?: "Planning…", style = MaterialTheme.typography.headlineSmall)
            Text(j.prompt, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { j.progress / 100f }, Modifier.fillMaxWidth())
            Text("${j.stage} · ${j.progress}% · build attempts: ${j.attempts}")
            j.error?.let { Text("Failed: $it", color = MaterialTheme.colorScheme.error) }
        }
        if (j.done) item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ vm.fetch(j, "apk", onInstall) }) { Text("Install APK") }
                OutlinedButton({ vm.fetch(j, "source", onShare) }) { Text("Export source") }
            }
            Text("Installing needs 'Install unknown apps' permission for AutoForge. Android will prompt you.", style = MaterialTheme.typography.bodySmall)
        }
        if (j.limitations.isNotEmpty()) item {
            Text("Limitations (not implemented, by design)", style = MaterialTheme.typography.titleSmall)
            j.limitations.forEach { Text("• $it") }
        }
        if (j.assumptions.isNotEmpty()) item {
            Text("Assumptions made", style = MaterialTheme.typography.titleSmall)
            j.assumptions.forEach { Text("• $it") }
        }
        item { Text("Log", style = MaterialTheme.typography.titleSmall) }
        items(j.log.reversed()) { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun HistoryScreen(vm: Vm, open: (String) -> Unit) {
    if (vm.history.isEmpty()) { Text("No builds yet."); return }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(vm.history, key = { it.id }) { j ->
            Card(Modifier.fillMaxWidth().clickable { open(j.id) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(j.appName ?: j.prompt.take(40), style = MaterialTheme.typography.titleMedium)
                        Text(j.status + " · " + java.text.DateFormat.getDateTimeInstance().format(j.createdAt), style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton({ vm.delete(j.id) }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
        }
    }
}
